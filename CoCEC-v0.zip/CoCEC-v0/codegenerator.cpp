
#include <iostream>
#include <stdlib.h>
#include <string>
#include <sstream> //for char to string conversion
#include <fstream>      // std::ifstream


#include "irgenerator.h"
#include "basicfuns.h"

using namespace std;

//creates multi-lines destruct tactics, by splitting the , separated variables 
//into sub-list of 'destructargs' variables separated by, each preceded by 'destruct'. '
string createtactics (string vars, int destructargs) {
	string tactics = " ";
	int count = 0;
	int curpos = 0;
	bool firstslice = true;
	for (int i=0; i < vars.length(); i++) {
		if (vars[i] == ',' && i < vars.length()) {
			count++;
			if (count == destructargs) {
				//adjust alignment
				if (firstslice)
					tactics = "(destruct "+vars.substr(curpos,(i-curpos))+"; simpl; auto);\n";
				else 
					tactics = tactics + "       (destruct "+vars.substr(curpos,(i-curpos))+"; simpl; auto);\n";
				count = 0;
				curpos = i+1;
				firstslice = false;
			} 
		}	
	}
	//adjust alignment
	if (firstslice)
		tactics = " try " + tactics + "(destruct "+vars.substr(curpos,(vars.length()-curpos))+"; simpl; auto).";
	else tactics = " try " + tactics + "       (destruct "+vars.substr(curpos,(vars.length()-curpos))+"; simpl; auto).";
	return tactics;
}

//returns Coq proof script(s)
string* getproofscript (string fun1, string fun2) {

	string temp = fun1;
	string* proofscript = new string[3]; 
	string boolvars = removechar(' ', getids(temp.append(fun2))); 
	//Creating brute-force destruct at once. 
	proofscript[0] = "\n Proof. \n   destruct "+boolvars+"; simpl; auto. \n Qed.\n Print Assumptions boolean_equivalence.";
	//Creating brute-force destruct in parallel (destruct of destructargs = 8 variables at a time is the good)
	proofscript[1] = "\n Proof. \n   intros.\n  "+createtactics(boolvars,8)+"  \n Show.  \n Qed.\n"
		" Print boolean_equivalence.\n"
		" Print Assumptions boolean_equivalence.";
	proofscript[2] = "\n Proof. \n   intros; unfold sum; unfold prod. \n   "
		"repeat (\n    try reflexivity;\n    try DestructMatchArg \n   ); auto. \n Show. \n Qed. \n"
		" Print boolean_equivalence.\n"
		" Print Assumptions boolean_equivalence.";
		
	return proofscript;		
}

//Creates Coq proof file (libraries, theorem and proof of theorem)
string mkcoqfile (string fun1, string fun2, int tactic) {

    ofstream filehandle;
	string temp = fun1;
	string theorem = " ";
	string forall;
	string* proofscript = getproofscript (fun1, fun2); 	
	
	//get identifiers, separated by comma, used in the Boolean functions, and remove the spaces, if any
	string boolvars = removechar(' ', getids(temp.append(fun2))); 
	
	//string library = "\n Require Import balgebra.";
	string theoremdef;
	
	//remove 'forall ...:bool,' if no open variable in functions
	if (!hasid(boolvars))
		theoremdef = "Theorem boolean_equivalence: ";
	else 
		theoremdef = "Theorem boolean_equivalence: forall "+replacechar(',', ' ', boolvars)+":bool,";
		
	if ((fun1.length()+fun2.length()) > 85)    //align Boolean equation
		theorem = "\n   "+replacebit(fun1)+" = \n   "+replacebit(fun2)+".";
	else theorem = "\n   "+replacebit(fun1)+" = "+replacebit(fun2)+".";
	
	string coqfile = theoremdef+theorem+proofscript[tactic];

	return coqfile;
}
