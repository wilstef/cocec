#ifndef MKCOQFILE_H_INCLUDED
#define MKCOQFILE_H_INCLUDED

using namespace std;  		//needed for string types

 string checkequivalence (string coqfile, string fun1, string fun2, int outputbitno);
 string replacevar (string str, char variable, string value);
 int runcoqchecker (string coqfile, int outputbitno);
 string invertvalue (string str);
 string createcounterexample (string pendinggoal, string fun1, string fun2, int outputbitno);
 
 string replacesubstr (string str, string strold, string strnew);
 string proveequivalence (string coqfile, string fun1, string fun2, int outputbitno);
 string getcounterexampleline (string ce);

#endif 