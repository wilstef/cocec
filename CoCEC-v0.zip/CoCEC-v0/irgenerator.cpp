#include <iostream>
#include <stdlib.h>
#include <string>
#include <sstream> //for char to string conversion
#include <fstream>      // std::ifstream

#include "basicfuns.h" 

using namespace std;

string generateIR (string fun) 
{
	fun = format_syntax(fun);				//position comma ' (for complement) as prefix notation
	fun = addprodchar(fun);					//add product char
	fun = replacemultchar('\'', "¬", fun);	//replace all commas with negation symbol (for complement)
	return fun;	
}
