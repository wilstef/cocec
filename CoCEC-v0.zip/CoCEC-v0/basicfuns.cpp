#include <iostream>
#include <stdlib.h>
#include <string>
#include <sstream> //for char to string conversion
//#include <windows.h>  //for GetModuleFileName
#include <vector>

#include <fstream>      // std::ifstream
#include "basicfuns.h"
#include <unistd.h>


//for getting current working directory
#include <stdio.h>  /* defines FILENAME_MAX */
// #define WINDOWS  /* uncomment this line to use it for windows.*/ 
#ifdef WINDOWS
#include <direct.h>
#define GetCurrentDir _getcwd
#else
#include <unistd.h>
#define GetCurrentDir getcwd
#endif
 

using namespace std;

//store errors to be displayed by the window functions
string syntaxerror = " ";

//erase all occurrences of pattern
string erasesubstr(string str, string pattern) {
	for(string::size_type i = str.find(pattern); i != string::npos; i = str.find(pattern))
		str.erase(i,pattern.length());

	return str;
}

//count occurrences of a char in a string
int countchar(char c, string str) {
  int count = 0;

  for (int i = 0; i < str.length(); i++)
    if (str[i] == c) 
		count++;

  return count;
}

int countsubstr(string substr, string str) {
	int count = 0;
	std::string::size_type pos = 0;
   while ((pos = str.find(substr, pos )) != std::string::npos) {
          ++count;
          pos += substr.length();
   }
   
   return count;
}

//converts a char to single letter string
 string ctostr(char c) {
	stringstream ss;
	string s;
	ss << c;
	ss >> s;
	return s;
   }
   
 //remove all occurrences of char ch from string str
 string removechar(char ch, string str){
	string temp = " ";
	int size = str.length();
	int i = 0;
	
	if (str == "" || str == " ")
		return " ";
	
	//ignore the last null char
	for(int j = 0; j<size; j++)
    {				
		if (str[j] != ch) {
			if (temp == " ")  //replace initialized (above) space in temp with a char other than 'ch'
				temp = ctostr(str[j]);
			else 
				temp = temp + str[j];
		}
	}	
	return temp;
 }
 
 
string GetCurrentWorkingDir( void ) {
  char buff[FILENAME_MAX];
  GetCurrentDir(buff, FILENAME_MAX);
  string current_working_dir(buff);
  return current_working_dir;
}

//return full path (in the current directory) of the destination file
string getdestfilepath (string destfilename) {
    string destfilepath = " ";
	
	string curdir = GetCurrentWorkingDir();
	destfilepath = curdir + "\\"+destfilename; 
	
    return destfilepath;
}

//converting integer number to string
string tostring (int num) {
    //output string stream
    ostringstream str1;
 
    //store number as a stream into output string
    str1 << num;
 
    //covert and return number into string
    return str1.str();
   } 



//check if a char is in valid Boolean term (only single letter variables or 0,1 are valid)
bool isboolterm(char c){
	string valid = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01";
	
	for (int i = 0; i <=valid.length(); i++)
		if (c == valid[i])
			return true;	
	return false;	
 }
 
//checks if a Boolean expression has variable
bool isboolid(char c) {
	string valid = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	
	for (int i = 0; i <=valid.length(); i++)
		if (c == valid[i])
			return true;	
	return false;	
 }
 
//checks if a string (fun or bool variables list) has any identifier 
//returns false, if the str (function) has just 1/0 (for true/false)
//returns false, if the str (boolvars list) is empty
bool hasid (string str) {

	for (int i = 0; i< str.length(); i++)
		if (isboolid(str[i]))
			return true;
			
	return false;
}
 
 
 //find if a char is a digit 0 or 1
 bool isbit(char c){
	string digits = "01";
	
	int i = 0;
	while (i < 2){
		if(c == digits[i])
			return true;
		i = i + 1;
	}

	return false;	
 }
		
 //shifts (left) a char from its current position to a newposition.
 string shiftchar (int curpos, int newpos, string fun) {
    
	char temp = fun[curpos];	
	for (int i=curpos; i > newpos; i--) {
		fun[i] = fun[i-1];
	}
	fun[newpos] = temp;
	
	return fun;
   }

		
 //replace post-complement with pre-complement (e.g., replaces (A+B)' with '(A+B))
 string format_syntax (string fun) {
    int countpar = 0;
	int curpos;
	int newpos;
	
	for (int i=0; i < fun.length(); i++) {	
		if(fun[i] == '\'' && isboolterm(fun[i-1]) ) {
			fun = shiftchar(i, i-1, fun);
		}
		if(fun[i]=='\'' && fun[i-1]==')') {
			curpos = i;
			countpar++;
			for(int j=i-2; j>=0 && countpar>0; j--) {				
				if(fun[j] == ')')
					countpar++;
				if(fun[j] == '(')
					countpar--;	
				newpos = j;
			}
			fun = shiftchar(curpos, newpos, fun);			
		}	
	}
	
	return fun;
   }
   
 
 //replace ''' (comma) in string with a char
 string replacechar (char oldchar, char newchar, string fun) {
	for (int i=0; i < fun.length(); i++) 
		if(fun[i] == oldchar) {
			fun[i] = newchar;
		}
	
	return fun;
   }
   
 //replace ''' (comma) in string with a multi-char (string) char
 string replacemultchar (char oldchar, string newchar, string fun) {
	string replaced = " ";
	for (int i=0; i < fun.length(); i++) {
		if(fun[i] == oldchar)
			replaced.append(newchar);
		else 			
			replaced.append(ctostr(fun[i]));
	}
	
	return replaced;
   }
   
 //assumes, no spaces in the string.
 //assumes, complement (comma) is in pre-fix form
 //assumes, comma is not yet replaced with ¬
 //Insert product operator
 string addprodchar (string fun) {
	string tempfun = " ";
	int j=0;
	
	for(int i=0; i<fun.length(); i++){
		tempfun.append(ctostr(fun[i]));
		j++;
		//an identifier must follow (except at last position) *, if not followed by + or )
		if (isboolterm(fun[i]) && i != fun.length()-1 && fun[i+1] != '+' && fun[i+1] != ')') {		//an identifier must follow a + or * character
			tempfun.append(ctostr('*'));
			j++;
		}	
		//insert product operator inside ) and (, inside ) and '   (A+B)(C+D), (A+B)~(C+D)
		if (fun[i] == ')' && (fun[i+1] == '(' || fun[i+1] == '\'')) {
			tempfun.append(ctostr('*'));
			j++;		
		}		
	}

	return tempfun;
	}
	
//finds a char in string
 bool findchar (char c, string str){
	for(int i = 0; i < str.length(); i++)
		if(str[i] == c)
			return true;
	return false;
 }
 
 //replace bits 1 and 0 with true and false.
 string replacebit (string str) {
	string temp = " ";
	
	for (int i = 0; i < str.length(); i++) {
		if (isbit(str[i])) {
			if (str[i] == '1')
				temp = temp + "true";
			else temp = temp + "false";
		}
		else temp = temp + str[i];
	}		
	return removechar (' ', temp);  //remove the initial space
 }
   
string getids (string fun) {
	string boolvars = " ";
	for(int i=0; i<fun.length(); i++) {
		if(isboolterm(fun[i]) && !isbit(fun[i]) && !findchar(fun[i], boolvars))
			if(boolvars == " ")
				boolvars.append(ctostr(fun[i]));
			else
				boolvars.append(","+ctostr(fun[i]));
	}
	return boolvars;
 }

int countachar (char c, string str) {
	int count = 0;
	for(int i=0; i<str.length(); i++) {
		if(str[i] == c)
			count++;
	}
	return count;
 }

 int clearfiles () {
	ofstream filehandle;
	
	filehandle.open ("counterexample.txt"); 
	filehandle << " "; //clear the text file  
	filehandle.close();	
	
	filehandle.open ("proofobject.txt"); 
	filehandle << " "; //clear the text file  
	filehandle.close();	
	
	filehandle.open ("proofscript.v"); 
	filehandle << " "; //clear the text file  
	filehandle.close();	
	
	filehandle.open ("coqerror.txt"); 
	filehandle << " "; //clear the text file  
	filehandle.close();	
	
	return 0;
}


  //erase comments (text after // and between /* */)
 string erasecomments (string str){
	string nocomments;	
	int i = 0;
	
	while (i < str.length()){
		
		//skip string after '//' till end of line
		if (str[i] == '/' && str[i+1] == '/'){
			//skip chars after // till end of line
			while (str[i] != '\n' && i < str.length())
				i = i + 1;
			i = i + 1;  //char after '\n' 
		}
		
		//skip string between /* and */
		if (str[i] == '/' && str[i+1] == '*'){
			i = i + 2;
			//skip chars between /* and */
			while (str[i] != '*' && str[i+1] != '/' && i < str.length())
				i = i + 1;
			i = i + 2;			//char after */ 
		}
		
		//add the rest of characters
		nocomments = nocomments + str[i];
		
		i = i + 1;
	}
	 
	return nocomments;
 }
 
/*
 //Split string, by a delimiter char, into an string array
 vector<string> splitstr(string str, char delim) {
	vector<string> strarray;
	
	int start = 0; 
	string tempstr;
	for(int i=0; i<str.length(); i++){		
		if (str[i] == delim) {
			tempstr = str.substr(start, (i-start));
			strarray.push_back(tempstr);
			start = i + 1;
	    }		
	}
	
	tempstr = str.substr(start, (str.length()-start));
	strarray.push_back(tempstr);
		
   return strarray; 
 } 
 */