
#ifndef CODEGENERATOR_H_INCLUDED
#define CODEGENERATOR_H_INCLUDED

using namespace std;  		//needed for string types

 string* getproofscript (string fun1, string fun2);
 string mkcoqfile (string fun1, string fun2, int tactic);
 string createtactics (string vars, int destructargs);

#endif 