#include <iostream>
#include <stdlib.h>
#include <string>
#include <sstream> //for char to string conversion
#include <fstream>      // std::ifstream

#include <algorithm>


#include "irgenerator.h"
#include "basicfuns.h"
#include "codegenerator.h"

using namespace std;

//invert Boolean values 'true' and 'false'
string invertvalue (string str) {

  if (str == "true")
	return "false";
  else if (str == "false")
	return "true";
  else {
  cout<<"\nError: trying to invert an invalid Boolean value:"<<str<<":"; 
  return "Error";  
  }
}

//replace variable with 1 or 0 (to be replaced with true or false later)
 string replacevar (string str, char variable, string value) {
	string temp = " ";
	
	for (int i = 0; i < str.length(); i++) {
		if (str[i] == variable) {
			if (value == "true")
				temp = temp + "1";
			else temp = temp + "0";
		}		
		else temp = temp + str[i];
	}		
	return removechar (' ', temp);  //remove the initial space
 }
 
//replaces a sub-string. replace strold with strnew in str (e.g., replaces all 'true' with '1'
 string replacesubstr (string str, string strold, string strnew) {
	string replaced = " ";
	int loc = 0;
	
	while (loc < str.length()) {
		int oldloc = loc;
		loc = str.find(strold, loc);
		if (loc != string::npos) {
			replaced = replaced + str.substr(oldloc, loc-oldloc) + strnew;
			//replaced.append(str.substr(oldloc, loc-oldloc)).append(strnew);
			loc = loc+strold.length();	
		}
		else 
		replaced = replaced + str.substr(oldloc, str.length()-oldloc);
	}
	return replaced;
 }
  
/*Creates counter example from the current pending goal (shown by Show Coq command). It gets two functions
in Coq syntax and the last pending goal (as stored by Coq Show command in proofobject, which include all the 
hypothesis, goal, and pending goals) where Coq stuck.  It returns the body of the goal (Coq current goal, 
below line as printed in the Coq right-top window) and saves the counter example in the counterexample.txt file. */
string createcounterexample (string pendinggoal, string fun1, string fun2, int outputbitno) {
	int colpos = 0;
	int assignpos = 0;
	int endofline = 0;
	int count = 0;
	string lhs;
	bool even = false;	
	char variable;
	string value;
	ofstream filehandle;
	string counterexample;
	string goal;
	string hypothesis;
	string origfun1 = fun1; string origfun2 = fun2;
	
	int horline = pendinggoal.find("============================");  //28
	int hypstart = pendinggoal.find("HYP");	
	
	//if no horizontal line, invalid gaol
	if (!(horline != string::npos))
		return " ";
	
	if (hypstart != string::npos) {
		hypothesis = pendinggoal.substr(hypstart, horline-hypstart);
	
		for (int i=0; i<hypothesis.length(); i++) {
	
			while(hypothesis[i] != '\n') {
				if (hypothesis[i] == ':')
					colpos = i;
				if (hypothesis[i] == '=')
					assignpos = i;
				i = i + 1;
			}
			endofline = i; //i is at '\n'
	
			lhs = hypothesis.substr(colpos+1, assignpos-colpos-1);
		
			if (lhs.length() == 1) {  //normal variable in hypothesis
				variable = hypothesis[assignpos-1];  
				value = hypothesis.substr(assignpos+1, endofline-assignpos-1); //right side of assign
				//replace values true/false with 1/0. 
				//this is required to allow letters t,r,u,e,f,a,l,s as variables
				fun1 = replacevar(fun1, variable, value);	
				fun2 = replacevar(fun2, variable, value);
			}
			else {
				//count = countchar('¬', lhs);
				count = countsubstr ("¬", lhs); //count occurences of substr ¬ 
				if (lhs.length()-(count*2) == 1) {  // ¬s (negations) precedes an identifier. each ¬ is stores as 2-char string
					variable = hypothesis[assignpos-1]; 
					if (count % 2)  //odd number of ¬s 
						value = invertvalue(hypothesis.substr(assignpos+1, endofline-assignpos-1)); //right side of assign, value, inverted
					else 
						value = hypothesis.substr(assignpos+1, endofline-assignpos-1); //right side of assign, value, inverted
					fun1 = replacevar(fun1, variable, value);	//replace values true/false with 1/0
					fun2 = replacevar(fun2, variable, value);   //replace values true/false with 1/0	
				} 	
				//else continue, skip hypothesis of the form ...value = value (e.g., ¬true = false)
			}	
		}
	}
	
		//get goal line
		int k=horline+29;
		int goalstart = k;
		while(pendinggoal[k] != '\n')
			k=k+1;
		goal = pendinggoal.substr(goalstart, k-goalstart);
			
	string editgoal = goal; 
	editgoal.insert(goal.find("="), " !"); //add inequality symbol
	editgoal.insert(goal.find("=")+3, " ");  //add space after =
		
	//replaces bits 0/1 with false/true in functions
	fun1 = replacebit(fun1);
	fun2 = replacebit(fun2);
	
	//in case of error (un-equal functions), remove spaces from message added by Coq 'Show' command
	filehandle.open ("counterexample.txt");  //update 'counterexample.txt' file
	filehandle << " "; //clear the text file  
	filehandle << "\n Outputs at position "+tostring(outputbitno) + " are not equal!";
	counterexample = fun1+" != " + fun2 + " ==> " + editgoal;	
	filehandle <<"\n "<<origfun1<<" != "<<origfun2+"\n\n"
			         "  *=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**\n"
					 "  Counterexample is the following!\n"
					 "  *=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**\n\n"
					 "  "+ counterexample + "\n\n"
					 "  *=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**";
	
	return goal;
 }
 
int runcoqchecker (string coqfile, int outputbitno) {

	ofstream filehandle;
	
	//get file content into a string
	std::ifstream t1("proofscript.v");    //std::ifstream::in
	std::stringstream buffer1;
	buffer1 << t1.rdbuf();
	string prevscript = buffer1.str(); 
		
    if (prevscript.find("Require Import balgebra.") != string::npos) 
		; //do nothing
	else prevscript = "\n Require Import balgebra. ";
	
	//Creates a unique theorem name (boolean_equivalenceI, where I is the output bit position-from left-to-right)
    coqfile = replacesubstr(coqfile, "boolean_equivalence", "boolean_equivalence_"+tostring(outputbitno)); 
 
 	prevscript = prevscript + "\n\n" + coqfile;
	//Create and open proofscript.v file in current directory (for Coq)
	filehandle.open ("proofscript.v"); 
	filehandle << prevscript;
	filehandle.close();
	
	//proofobject.txt stores proof terms (if closed), otherwise, current goal (where the proof is stuck)
	//clear 'proofobject.txt' file for new input
	filehandle.open ("proofobject.txt"); 
	filehandle << " "; //clear the text file  
	filehandle.close();
	
	//clear 'coqerror.txt' file for new input
	filehandle.open ("coqerror.txt"); 
	filehandle << " "; //clear the text file  
	filehandle.close();
	
	//get the current path for destination Coq file. \" are to accept spaces
	//">> proofscript.txt 2>> coqerror.txt" adds coqc message to proofobject.txt and Coq error to coqerror.txt. 
	
	string dospath = "coqc \"" + getdestfilepath("proofscript.v") + "\">> proofobject.txt 2>>coqerror.txt";
	
	int errorno = system(dospath.c_str()); 
	
	return errorno;
}


//returns a string error. The error is single character empty string, in case of fatal error: out of memory
string checkequivalence (string coqfile, string fun1, string fun2, int outputbitno) {
	ofstream filehandle;
	int errorno; 
	string goal = " ";
	
	//run Coq to check the input Coq proof script
	errorno = runcoqchecker (coqfile, outputbitno);
	
	//clear 'counterexample.txt' file for new input
	filehandle.open ("counterexample.txt"); 
	filehandle << " "; //clear the text file  
	filehandle.close();	
	
	//get file content into a string
	std::ifstream t1("proofobject.txt");    //std::ifstream::in
	std::stringstream buffer1;
	buffer1 << t1.rdbuf();
	string okmessage = buffer1.str();  //proof object/term  (success) or last pending goal (failure)
	
	std::ifstream t2("coqerror.txt");    //std::ifstream::in
	std::stringstream buffer2;
	buffer2 << t2.rdbuf();
	string errormessage = buffer2.str();   //Coq error message 
		
	string status;
	if (errorno == 0 && okmessage.find("Closed under the global context") != string::npos) { //no system error
			status = "equal";
			
			string pattern1 = "Closed under the global context";
			string pattern2 = "No more subgoals.";
			string pattern3 = "Coq proof term(s)/object(s): \n**********************";
			
			//erase all occurrences of pattern1
			okmessage = erasesubstr(okmessage, pattern1);
			//erase all occurrences of pattern2
			okmessage = erasesubstr(okmessage, pattern2);
							
			//append pattern3 at the beginning of 'proofobject'
			if(okmessage.find(pattern3) != string::npos)
				; //do nothing
			else okmessage = "\n" + pattern3 + "\n"+okmessage;
			
			filehandle.open ("proofobject.txt");  //update 'proofobject.txt' file. It keeps only proof object/term
			filehandle <<okmessage;
			filehandle.close();
	}
	else if (errorno == 1 && errormessage.find("Error: Attempt to save an incomplete proof") != string::npos) {  //system (Coq Qed) error		
			//in case of error (un-equal functions), remove spaces from message added by Coq 'Show' command
			okmessage = removechar (' ', okmessage); 
			filehandle.open ("proofobject.txt");  //update 'proofobject.txt' file. It keeps only proof object/term
			filehandle <<okmessage;
			filehandle.close();
			//okmessage = getcounterexample(okmessage, fun1, fun2); //functions are not equal, so instead save coutnerexample 
			goal = createcounterexample(okmessage, fun1, fun2, outputbitno); //functions are not equal, so instead save coutnerexample
			
			string replacedgoal = replacesubstr(replacesubstr(goal,"true","1"), "false", "0");
			string boolvars = " ";
			if (hasid(replacedgoal))
				boolvars = removechar(' ', getids(replacedgoal)); 
						
			//Michale's Coq tactic (in balgebra.v) does not destruct terms without operator (e.g., x = y).
            //To destruct all variable still available in the goal (after Michale's tactic is once used), ordinary destruct over
			//them is used, and all the goal terms are combined in a single counter example (see proveequivalence.txt). 
			//This normally happens in inequality cases, such as testing x = y. 
			if (boolvars != " ")  //some open variable in the goal
				return replacedgoal;  //re-call Coq to destruct the open variables in the goal
			else
			    return "unequal";	
		}
		
	else status = "wrongtranslation";  //syntax or type error in Coq code, caused by mistaken translation
	
	return status;
} 

//return the counter-example line from a counter example string 
//returns just the counterexample from counterexample.txt file 
string getcounterexampleline (string ce) {
	int loc = 0; int temploc=0;
	string line = "*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**";
	
	loc = ce.find(line); //find first line
	if (loc != string::npos)  {
		loc = ce.find(line, loc+line.length()); //find second line
	if (loc != string::npos) {
		int k = loc+line.length()+6;
		int endofline = k;
		while (ce[k] != '\n')
			k++;
		endofline = k;
		ce = ce.substr(loc+line.length()+4, k-(loc+line.length()+4));
		return ce;
	}
	}
	return "\nError: Invalid sub-counter example!";
}


string proveequivalence (string coqfile, string fun1, string fun2, int outputbitno) {
	ofstream filehandle;
	string origfun1 = fun1; string origfun2 = fun2;	
	string tempfun1; string tempfun2;
	
	string status = checkequivalence (coqfile, origfun1, origfun2, outputbitno);
	
	//Check if the major tactic 'DestructMatchArg' has not solved the goal, re-create theorem statement 
	//and apply ordinary destruct tactic on the same theorem. 
	if (status != "equal" && status != "unequal" && status.find("=") != string::npos) {
		int loc = status.find("=");
		tempfun1 = status.substr(0, loc);
		string tempfun2 = status.substr(loc+1, status.length()-loc);
		string coqfile = mkcoqfile (tempfun1, tempfun2, 1); //checks the second (1) tactic. 
		
		//get old first version of counter example
		std::ifstream t1("counterexample.txt");    //std::ifstream::in
		std::stringstream buffer1;
		buffer1 << t1.rdbuf();
		string ceold = buffer1.str();  //counter example old
		
		tempfun1 = replacebit(tempfun1);
		tempfun2 = replacebit(tempfun2);
		
		//delete old proof script created with 'DestructMatchArg' tactic. 
		filehandle.open ("proofscript.v"); 
		filehandle << " "; //clear the text file  
		filehandle.close();	
		//This time check equivalence with ordinary destruct (proofscript[1] in 'getproofscript' function)
		status = checkequivalence (coqfile, tempfun1, tempfun2, outputbitno);  //add new version of counter example
		
		//get new first version of counter example
		std::ifstream t2("counterexample.txt");    //std::ifstream::in
		std::stringstream buffer2;
		buffer2 << t2.rdbuf();
		string cenew = buffer2.str();  //counter example new
		
		ceold = getcounterexampleline (ceold);
		cenew = getcounterexampleline (cenew);
		
		filehandle.open ("counterexample.txt");  //update 'counterexample.txt' file
		filehandle << " "; //clear the text file 
		filehandle << "\n Outputs at position "+tostring(outputbitno) + " are not equal!";
		filehandle <<"\n "<<origfun1<<" != "<<origfun2+"\n\n"
			         "  *=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**\n"
					 "  Counterexample is the following!\n"
					 "  *=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**\n\n"
					 "  "+ ceold + "\n"
					 "  "+ cenew + "\n\n"
					 "  *=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**=*=**";
	}	
	return status;
}
