#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

using namespace std;  		//needed for string types

 string parser(string description);
 //int countsubstr(string str, string pattern);

#endif 