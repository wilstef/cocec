#ifndef BASICFUNS_H_INCLUDED
#define BASICFUNS_H_INCLUDED

using namespace std;  		//needed for string types

//general functions
string erasesubstr(string str, string pattern);
 string removechar(char ch, string str);
 bool isboolterm(char c);
 bool isboolid(char c);
 bool isdigit(char c);
 bool check_syntax(string fun);
 string shiftchar (int curpos, int newpos, string fun);
 string format_syntax (string fun);
 string ctostr(char c);
 string replacechar (char oldchar, char newchar, string fun);
 string replacemultchar (char oldchar, string newchar, string fun);
 string addprodchar (string fun);
 bool findchar (char c, string str);
 string getids (string fun);
 extern string syntaxerror;  //global variable for errors (used by check_syntax and window function)
 string getdestfilepath (string destfilename);
 string replacebit (string str);
 string tostring (int num);
 int countachar (char c, string str); 
int countchar(char c, string str);
int countsubstr(string substr, string str);
bool hasid (string str);
string GetCurrentWorkingDir();
int clearfiles ();
string erasecomments (string str);
//vector<string> splitstr(string str, char delim);

#endif //BASICFUNS_H_INCLUDED
