#include <iostream>
#include <stdlib.h>
#include <string>
#include <sstream> //for char to string conversion
#include <fstream>      // std::ifstream
#include <vector>
//#include <tuple>

#include "syntaxchecker.h"
#include "basicfuns.h"

using namespace std;

/*
//comments
begin module
	Output x+xy;
	Output a+ab;
end module
*/
  
string parser(string description) {
	//description = "//comments \n begin module \n		Outpu x+xy;\n   Output  a+ab;\n  Output c+ad; end module";
	string parseerror; 
	bool error = false;
	
	vector<string> outputs;
	string outputfuns = " ";
	
	//Preprocessing
	description = erasecomments (description);  //remove comments
	description = removechar (' ', description); //remove spaces
	description = removechar ('\n', description); //remove newlines
	description = removechar ('\t', description); //remove tabs
	
	int beginmodloc = description.find("beginmodule");
	int endmodloc = description.find("endmodule");
	
	//check if 'begin module' and 'end module' is correct
	if (beginmodloc != string::npos) {
		if(endmodloc != string::npos) {
			description = description.substr(beginmodloc+11, description.length()-(11+9+1)); //skip 'beginmodule', 'endmodule' and last ';'
			
			outputs = split_circuit(description, ';');
						
			//separate output statements/functions
			for(int i=0; i<outputs.size(); i++) {
				int outputpair = outputs.size() - i;
				int outputloc = outputs[i].find("Output");
				if (outputloc != string::npos) {
					if (countsubstr("Output",outputs[i]) > 1)
						return parseerror = "Parse-error-code-204: Missing semicolon in output "+tostring(outputpair); 
				
					else if(i == 0)
							outputfuns = outputs[i].substr(outputloc+6, outputs[i].length()-6);
						else outputfuns = outputfuns + ":" + outputs[i].substr(outputloc+6, outputs[i].length()-6);
				}
				else {
					parseerror = "Parse-error-code-203: 'Output "+tostring(outputpair-1)+"' is incorrect.";
					error = true;
					break;
				} 				
			}			
		} 
		else {
			parseerror = "Parse-error-code-200: incorrect use of keywords 'end module'.";
			error = true;
		} 
	}
	else {
		parseerror = "Parse-error-code-201: incorrect use of keywords 'begin module'.";
		error = true;
	}
				
	if(error)
		return parseerror;
	else 
		return outputfuns;
}