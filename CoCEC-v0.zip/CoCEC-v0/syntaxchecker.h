#ifndef SYNTAXCHECKER_H_INCLUDED
#define SYNTAXCHECKER_H_INCLUDED

using namespace std;  		//needed for string types

//general functions
bool check_syntax_fun(string fun, int functionpos);
vector<string> split_circuit(string circuit, char delim);
bool check_syntax_circuit(vector<string> cirfunctions);
int funslen(vector<string> cirfunctions, int lastfunpos);
int isanystrempty(vector<string> strvector);

#endif //BASICFUNS_H_INCLUDED