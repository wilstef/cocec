#include <iostream>
#include <stdlib.h>
#include <string>
#include <sstream> //for char to string conversion
//#include <windows.h>  //for GetModuleFileName
#include <vector>

#include "basicfuns.h"
 
 //Checks if syntax of the Boolean function is correct
 /* Valid function rules:
	- id is preceded by (except first id) id, +, space, ( or )
	- ' is preceded by id, ' or )
	- + is preceded by space, id, ) or ' 
    - ( is preceded by +, id, (, or '
	- ) is preceded by id, ', )
	- last char must be an id, ' or )
	Exceptions: id and ( at first location are not preceded by any char	
	NOT ALLOWED: 
		- empty parenthesis ()
		- chars, other than ', +, id, ) or (  
		- spaces (only when input is given on command prompt)				
*/
 bool check_syntax_fun(string fun, int functionpos) {
	int parencount = 0;   //count parenthesis pairs
	int funlen = fun.length();
		
	//if an output function of a circuit is empty.
	if (fun == " ") {
		syntaxerror = "The output function "+tostring(functionpos+1)+" is invalide.";
		return false;
	}
	
	
	//Check if parenthesis are closed. 
	for (int q=0; q < funlen; q++){
		if(fun[q] == '(')
			parencount++;
		if(fun[q] == ')')
			parencount--;	
	}
	if (parencount != 0) {
		//cout<<"Error: invalid function \n";
		//cout<<"Mis-match parenthesis. \n";
		syntaxerror = "Mis-match parenthesis.";
		return false;
	}
	
	int j = 0;
	//The function must begin with a valid identifier or opening parenthesis
	if (isboolterm(fun[j]) || fun[j] == '(') 		//checks the first non-space character
		j++;		 		//if valid id, move pointer to next character
	else {
		syntaxerror = "The character "+ctostr(fun[j])+" at position "+tostring(functionpos+j)+" is invalid.";
		return false;
	}
	
	for (int i = j; i < funlen; i++){
	    	
		//only id, ' or ) is allowed at last position
		if ((!isboolterm(fun[funlen-1]) && fun[funlen-1] != '\'' && fun[funlen-1] != ')')){
			syntaxerror = "The character "+ctostr(fun[funlen-1])+" at position "+tostring(functionpos + (funlen-1))+" is miss-placed or invalid.";
			return false;
		}					
		//id is preceded by (except first id) id, +, space, ( or )
		if (isboolterm(fun[i]) && (fun[i-1] == '\'' || isboolterm(fun[i-1]) || fun[i-1] == '+' || fun[i-1] == '(' || fun[i-1] == ')')) 
			continue;
		//' is preceded by id, ' or )
		if (fun[i] == '\'' && (isboolterm(fun[i-1]) || fun[i-1] == '\'' || fun[i-1] == ')'))  //a ' must be preceded by an id, ', )
			continue;
		//+ is preceded by id, ) or '
		if (fun[i] == '+' && (isboolterm(fun[i-1]) || fun[i-1] == '\'' || fun[i-1] == ')'))
			continue;
		//( is preceded by +, id, (, or '
		if (fun[i] == '(' && (fun[i-1] == '+' || isboolterm(fun[i-1]) || fun[i-1] == '(' || fun[i-1] == ')' || fun[i-1] == '\''))
			continue;
		//) is preceded by id, ', )
		if (fun[i] == ')' && (isboolterm(fun[i-1]) || fun[i-1] == ')' || fun[i-1] == '\''))
			continue;	
		else{
			syntaxerror = "The character "+ctostr(fun[i])+" at position "+tostring(functionpos+i)+" is invalid.";
			return false;
		}				
	}
    return true;
 }
 
 
//Split colon-separated string (circuit) into ingredient functions
 vector<string> split_circuit(string circuit, char delim) {
	vector <string> functions;
	
	int start = 0; 
	string function;
	for(int i=0; i<circuit.length(); i++){		
		if (circuit[i] == delim) {
			function = circuit.substr(start, (i-start));
			functions.push_back(function);
			start = i + 1;
	    }		
	}
	
	function = circuit.substr(start, (circuit.length()-start));
	functions.push_back(function);
		
   return functions; 
 } 
 
 
//Calculate sum of length of functions (up to an index) in vector
int funslen(vector<string> cirfunctions, int lastfunpos) {
	int funslen = 0;
	
	for(int i=0; i<lastfunpos; i++) 
		funslen = funslen+cirfunctions[i].length() + 1;  //1 is added for every :, in circuit separating functions
		
	return funslen; 
 }
 
 
 bool check_syntax_circuit(vector<string> cirfunctions) {
	bool correct = true;
		
	for(int i=0; i<cirfunctions.size(); i++) {
		if(check_syntax_fun(cirfunctions[i], funslen(cirfunctions, i))) 
			continue;
		else 
			return false;	
	}	
	return correct; 
 }

 
 //checks if any string is empty in a string vector. returns position (0-n) of string, else -1
//used for checking if any function in a circuit (string vector)is empty.
 int isanystrempty(vector<string> strvector) {
	
	int position = -1;
	
	for(int i=0; i<strvector.size(); i++){		
		if (strvector[i] == "") 
			return i;
		else continue;		
	}
			
   return position; 
 } 