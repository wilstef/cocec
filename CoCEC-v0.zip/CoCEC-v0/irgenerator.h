#ifndef IRGENERATOR_H_INCLUDED
#define IRGENERATOR_H_INCLUDED


using namespace std;  		//needed for string types

string generateIR (string fun);

#endif //BASICFUNS_H_INCLUDED