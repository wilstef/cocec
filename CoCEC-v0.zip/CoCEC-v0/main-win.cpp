#include <windows.h>
#include <string>
#include <iostream>

#include <stdlib.h>
#include <sstream> //for char to string conversion
#include <fstream>      // std::ifstream
#include <vector>



#include <Commdlg.h>

#include "basicfuns.h"
#include "irgenerator.h"
#include "syntaxchecker.h"
#include "codegenerator.h"
#include "proofchecker.h"
#include "parser.h"

#include "time.h"


#define ID_EDITCHILD 100

using namespace std;

/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

/*  Make the class name into a global variable  */
char szClassName[ ] = "BoolCheckWindowsApp";
//Two Boolean functions
string fun1 = " ";
string fun2 = " ";
string circuit1 = " ";
string circuit2 = " ";
vector<string> cirfuns1;
vector<string> cirfuns2;

HWND textbox1;
HWND textbox2;

string coqerror = " ";
bool validcircuit1 = false;
bool validcircuit2 = false;

int WINAPI WinMain (HINSTANCE hThisInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR lpszArgument,
                     int nCmdShow)
{
    HWND hwnd;               /* handle for window */
    MSG messages;            /* messages to the application */
    WNDCLASSEX wincl;        /* window class data structure */

	string dospath = "coqc \"" + getdestfilepath("balgebra.v");
	system(dospath.c_str()); 
	
    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* function called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;                 /* No menu */
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */
	
    /* Use Windows's default colour as the background of the window */
    wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

    /* Register the window class, and if it fails quit the program */
    if (!RegisterClassEx (&wincl))
        return 0;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx (
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           "CoCEC: Checking Combinational Circuits' Equivalence",       /* Title Text */
           WS_OVERLAPPEDWINDOW, /* default window */
           CW_USEDEFAULT,       /* Windows decides the position */
           CW_USEDEFAULT,       /* where the window ends up on the screen */
           544,                 /* The programs width */
           375,                 /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           NULL,                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

    /* Make the window visible on the screen */
    ShowWindow (hwnd, nCmdShow);

    /* Run the message loop. It will run until GetMessage() returns 0 */
    while (GetMessage (&messages, NULL, 0, 0))
    {
        /* Translate virtual-key messages into character messages */
        TranslateMessage(&messages);
        /* Send message to WindowProcedure */
        DispatchMessage(&messages);
    }
 
    /* The program return-value is 0 - The value that PostQuitMessage() gave */
    return messages.wParam;
}


/*  This function is called by the Windows function DispatchMessage()  */
LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    std::string input1;
	std::string input2;	  
		
    int emptyfunpos;	
	string errormsg;
	
    switch (message)                  /* handle the messages */
    {
        case WM_DESTROY:
            PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
            break;
		case WM_CREATE:
			/*
			CreateWindowEx(WS_EX_WINDOWEDGE, TEXT("STATIC"),
				TEXT("Welcome To BECheck Tool! \n Enter x' for x complement, + for sum and no symbol for product."), 
				WS_CHILD|WS_VISIBLE|SS_CENTER, 150,20,230,50,hwnd,HMENU(NULL),GetModuleHandle(NULL),NULL); */
				
			CreateWindowEx(WS_EX_WINDOWEDGE, TEXT("STATIC"),
				TEXT("Welcome To CoCEC Tool"), 
				WS_CHILD|WS_VISIBLE|SS_CENTER, 110,40,310,20,hwnd,HMENU(NULL),GetModuleHandle(NULL),NULL);
			
			
			textbox1 = 
			  CreateWindow ("edit", "Describe circuit 1", WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_BORDER | ES_MULTILINE, 110, 90, 310, 85, hwnd, (HMENU) 1000, GetModuleHandle (NULL), NULL);	
			SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, 0, -1);  //select and focus on first textbox
			SetFocus(GetDlgItem (hwnd, 1000));
			textbox2 = 
			  CreateWindow ("edit", "Describe circuit 2", WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_BORDER | ES_MULTILINE, 110, 180, 310, 85, hwnd, (HMENU) 1001, GetModuleHandle (NULL), NULL);
			CreateWindow ("button", "Check Equivalence", WS_CHILD | WS_VISIBLE, 110, 270, 150, 35, hwnd, (HMENU) 1002, GetModuleHandle (NULL), NULL);
			CreateWindow ("button", "Close", WS_CHILD | WS_VISIBLE, 320, 270, 100, 35, hwnd, (HMENU) 1003, GetModuleHandle (NULL), NULL);	
			CreateWindow ("button", "Load circuit 1", WS_CHILD | WS_VISIBLE, 425, 115, 100, 35, hwnd, (HMENU) 1004, GetModuleHandle (NULL), NULL);
			CreateWindow ("button", "Load circuit 2", WS_CHILD | WS_VISIBLE, 425, 205, 100, 35, hwnd, (HMENU) 1005, GetModuleHandle (NULL), NULL);
		
			
			break;
						
		case WM_COMMAND:
			switch (LOWORD (wParam)) {
				case 1003: {
					PostQuitMessage (0);    //close the main window-is quick
					//SendMessage(hwnd,WM_CLOSE,0,0);		//close the main window	
					return 0;
					}
					
				//When 'Load circuit 1' button clicked
				case 1004:
					{
					//copied from a http://www.cplusplus.com/forum/windows/72278/
					
					//Reads file path and name to a string variable. 
					//Add option '-lcomdlg32' for 'GetOpenFileName(&ofn)'
					OPENFILENAME ofn; //output file name
					char circuitfile1[MAX_PATH] = "";

					ZeroMemory(&ofn, sizeof(ofn));

					ofn.lStructSize = sizeof(ofn); // SEE NOTE BELOW
					ofn.hwndOwner = hwnd;
					ofn.lpstrFilter = "Text Files (*.txt)\0*.txt\0All Files (*.*)\0*.*\0";
					ofn.lpstrFile = circuitfile1;
					ofn.nMaxFile = MAX_PATH;
					ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
					ofn.lpstrDefExt = "txt";

					if(GetOpenFileName(&ofn))
					{
						//reads input '*.txt' file to a buffer
						std::ifstream t(circuitfile1);    
						std::stringstream buffer;
						buffer << t.rdbuf();
						string circuit1 = buffer.str();
						
						//parse circuit module: returns either an error message or sequence of output functions
						circuit1 = parser(circuit1);
						//set the text of textbox to the circuit description. 
						SetWindowText(textbox1, TEXT(circuit1.c_str()));
					}	
					return 0;
				}
				
				//When 'Load circuit 2' button clicked
				case 1005:
					{
					//copied from a http://www.cplusplus.com/forum/windows/72278/
					
					//Read file path and name to a string variable. 
					//Add option '-lcomdlg32' for 'GetOpenFileName(&ofn)'
					OPENFILENAME ofn;
					char circuitfile2[MAX_PATH] = "";

					ZeroMemory(&ofn, sizeof(ofn));

					ofn.lStructSize = sizeof(ofn); // SEE NOTE BELOW
					ofn.hwndOwner = hwnd;
					ofn.lpstrFilter = "Text Files (*.txt)\0*.txt\0All Files (*.*)\0*.*\0";
					ofn.lpstrFile = circuitfile2;
					ofn.nMaxFile = MAX_PATH;
					ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
					ofn.lpstrDefExt = "txt";

					if(GetOpenFileNameA(&ofn))  //and GetOpenFileName?
					{
						//reads input '*.txt' file to a buffer
						std::ifstream t(circuitfile2);    
						std::stringstream buffer;
						buffer << t.rdbuf();
						string circuit2 = buffer.str();
						
						//parse circuit module: returns either an error message or sequence of output functions
						circuit2 = parser(circuit2);
						
						//set the text of textbox to the circuit description. 
						SetWindowText(textbox2, TEXT(circuit2.c_str()));
					}
					
					return 0;
				}
				
				case 1002:  //if 'Check Equivalence' button clicked.
					{
					
						//clear all files prior every test
						clearfiles();
						
						//setting for time calculation - performance evaluation
					    clock_t start, end1, end2;
						start = clock(); 
								
						string input1;
						string input2;
										
						//read text (function 1) from first text box
						GetWindowText (GetDlgItem (hwnd, 1000), reinterpret_cast <char*> ((char *) input1.c_str ()), 300);
						//Pre-processing
						circuit1 = input1.c_str();
						circuit1 = removechar(' ', circuit1);  //remove spaces if any
						circuit1 = removechar('\t', circuit1); //remove tabs if any

						cirfuns1 = split_circuit (circuit1, ':');  //create circuit vector (string)
						
						//Check and notify if circuit 1 or any of its output function is empty.
						emptyfunpos = isanystrempty(cirfuns1);
						
						if (emptyfunpos >= 0 | circuit1 == " ") {
							if (circuit1 == " ") 
								errormsg = "No text entered for circuit 1!";
							else errormsg = "Output function "+tostring(emptyfunpos)+" (left-to-right) of circuit 1 is empty.";
						
							int msgbxid = MessageBox(0, errormsg.c_str(), "Warning", 
												MB_ICONWARNING | MB_OK | MB_DEFBUTTON1 | MB_TASKMODAL ); 
									switch (msgbxid) {
									    case IDOK:
											//Set cursor at the end of text-extra message is needed.
											SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, 0, -1);
											SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, -1, -1);
											SetFocus(GetDlgItem (hwnd, 1000));
											break;
									}
							return 0;
						}
						
						//continue with defined (non-empty) circuit
						
						//if Boolean function conforms to the rules in syntaxchecker.cpp
						if (check_syntax_circuit(cirfuns1)) {       //check syntax of circuit1
							validcircuit1 = true;
							//fun1 = generateIR (fun1);	//translates to formalized Boolean functions
							//MessageBox(0,fun1.c_str(), "Function 1", MB_OK );		//problem in chars conversion						
						} else  {
							syntaxerror = "Circuit 1 is invalid!\n"+syntaxerror;
							int msgbxid = MessageBox(0,syntaxerror.c_str(), "Error", 
										MB_ICONWARNING | MB_RETRYCANCEL | MB_DEFBUTTON1 | MB_TASKMODAL
										);
								switch (msgbxid) {
								    case IDRETRY:
										//Set cursor at the end of text in first text box
										SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, -1, -1);
										SetFocus(GetDlgItem (hwnd, 1000));
										break;
									case IDCANCEL:
										break;
								}
								
							validcircuit1 = false; 
							return 0;
						}
						//read text (function 2) from second text box
						GetWindowText (GetDlgItem (hwnd, 1001), reinterpret_cast <char*> ((char *) input2.c_str ()), 300);
						circuit2 = input2.c_str();
						circuit2 = removechar(' ', circuit2);  //remove spaces. All other function assume, there are no spaces
						circuit2 = removechar('\t', circuit2); //remove tabs if any

						//continue with defined (non-empty) circuit
						cirfuns2 = split_circuit (circuit2, ':'); //create circuit vector (string)
											
						//Check and notify if circuit 1 or any of its output function is empty.
						emptyfunpos = isanystrempty(cirfuns2);
						
						if (emptyfunpos >= 0 | circuit2 == " ") {
							if (circuit2 == " ") 
								errormsg = "No text entered for circuit 1!";
							else errormsg = "Output function "+tostring(emptyfunpos)+" (left-to-right) of circuit 2 is empty.";
						
							int msgbxid = MessageBox(0, errormsg.c_str(), "Warning", 
												MB_ICONWARNING | MB_OK | MB_DEFBUTTON1 | MB_TASKMODAL ); 
									switch (msgbxid)  {
									    case IDOK:
											//Set cursor at the end of text-extra message is needed.
											SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, 0, -1);
											SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, -1, -1);
											SetFocus(GetDlgItem (hwnd, 1000));
											break;
									}
							return 0;
						}
						
						//Check if both circuits have same number of outputs
						if(cirfuns1.size() != cirfuns2.size()) {
						    syntaxerror = " Error: Number of outputs of both circuits are different.\n ";
							syntaxerror = syntaxerror + "Outputs of circuit 1 are "+tostring(cirfuns1.size())+", while that of circuit 2 are "+tostring(cirfuns2.size());
							int msgbxid = MessageBox(0,syntaxerror.c_str(), "Error", 
										MB_ICONWARNING | MB_RETRYCANCEL | MB_DEFBUTTON1 | MB_TASKMODAL
										); 											
								switch (msgbxid) {
								    case IDRETRY:
										//Set cursor at the end of text-extra message is needed.
										SendMessage (GetDlgItem (hwnd, 1001),EM_SETSEL, 0, -1);
										SendMessage (GetDlgItem (hwnd, 1001),EM_SETSEL, -1, -1);
										SetFocus(GetDlgItem (hwnd, 1001));											
										break;
									case IDCANCEL:
										break;
								}	
							return 0;
						}
							
						if (check_syntax_circuit(cirfuns2)) {
							validcircuit2 = true;
							} else {
								syntaxerror = "Circuit 2 is invalid!\n"+syntaxerror;
								int msgbxid = MessageBox(0,syntaxerror.c_str(), "Error", 
											MB_ICONWARNING | MB_RETRYCANCEL | MB_DEFBUTTON1 | MB_TASKMODAL
											); 											
									switch (msgbxid) {
									    case IDRETRY:
											//Set cursor at the end of text-extra message is needed.
											SendMessage (GetDlgItem (hwnd, 1001),EM_SETSEL, 0, -1);
											SendMessage (GetDlgItem (hwnd, 1001),EM_SETSEL, -1, -1);
											SetFocus(GetDlgItem (hwnd, 1001));											
											break;
										case IDCANCEL:
											break;
									}		
								validcircuit2 = false; 
								return 0;
								}
						
						//if syntax of both functions are well-formed
						if (validcircuit1 & validcircuit2) {
							//cirfuns1 and cirfuns2 are of the same size.
							int funscount = cirfuns1.size();
							for(int i=0; i<funscount; i++){
								//translate  ith functions to corresponding formalized Boolean functions
								fun1 = generateIR (cirfuns1[i]);
								fun2 = generateIR (cirfuns2[i]);
								string coqfile = mkcoqfile (fun1, fun2,2);	
								coqerror = proveequivalence (coqfile,fun1,fun2,funscount-(i+1)); //pass on the output bit no (left-to-right)
								//if any two corresponding functions of both circuits were found unequal, break, else continue.
								if (coqerror == "equal")  {
									
									//post-processing: remove 'Show' and 'Print' tactics from the ith proved theorem in 'proofscript.v'
									std::ifstream t1("proofscript.v");    //std::ifstream::in
									std::stringstream buffer1;
									buffer1 << t1.rdbuf();
									string proofscript = buffer1.str();  //proof object/term  (success) or last pending goal (failure)
									proofscript = erasesubstr(proofscript, "Show.");
									proofscript = erasesubstr(proofscript, "Print boolean_equivalence_"+tostring(funscount-(i+1))+".");
									proofscript = erasesubstr(proofscript, "Print Assumptions boolean_equivalence_"+tostring(funscount-(i+1))+".");
									ofstream filehandle;
									filehandle.open ("proofscript.v"); 
									filehandle <<proofscript; //clear the text file  
									filehandle.close();										
									continue; 								
								}
								else break;							 
							}
											
							if (coqerror == "unequal") {
								int msgbxid = MessageBox(0, "Circuits are NOT equivalent!", "Equivalence Result", 
											MB_ICONASTERISK | MB_OKCANCEL | MB_DEFBUTTON1 | MB_TASKMODAL ); 
								switch (msgbxid) {
								    case IDOK:
										//Set cursor at the end of text-extra message is needed.
										SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, 0, -1);
										SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, -1, -1);
										SetFocus(GetDlgItem (hwnd, 1000));
										break;
									case IDCANCEL:
										SetFocus(GetDlgItem (hwnd, 1003));
										break;
								}	
							return 0;							
							}
							else if (coqerror == "equal") {
								string error = "Circuits are equivalent!\n"
								           "Click OK to show Coq proof object.\n"
										   "Click Cancel to return to main window.";
											int errorno;
											int msgbxid = MessageBox(0,error.c_str(), "Equivalence Result", 
												MB_ICONASTERISK  | MB_OKCANCEL | MB_DEFBUTTON1 | MB_TASKMODAL ); 
										switch (msgbxid) {
									    case IDOK:										
											//Open Coq proof object created for the proof script (output of command 'Print boolean_equivalence'). 
											errorno = system("start proofobject.txt");  //the 'start' is used to run Windows process in the background 
											//Set cursor at the end of text in first text box
											SendMessage (GetDlgItem (hwnd, 1000),EM_SETSEL, -1, -1);
											SetFocus(GetDlgItem (hwnd, 1000));		
											break;
										case IDCANCEL:
											SetFocus(GetDlgItem (hwnd, 1003));
											break;
									}
								return 0;
							}
							else {
								int msgbxid = MessageBox(0, "Function translation was not correct.", "Error", 
											MB_ICONWARNING | MB_RETRYCANCEL | MB_DEFBUTTON1 | MB_TASKMODAL ); 											
								switch (msgbxid) {
								    case IDRETRY:
										//Set cursor at the end of text-extra message is needed.
										SendMessage (GetDlgItem (hwnd, 1001),EM_SETSEL, 0, -1);
										SendMessage (GetDlgItem (hwnd, 1001),EM_SETSEL, -1, -1);
										SetFocus(GetDlgItem (hwnd, 1001));											
										break;
									case IDCANCEL:
										break;
								}
								return 0;
							}
							
						}
 
					}
					break;
			}
			break;
			default:                     
				return DefWindowProc (hwnd, message, wParam, lParam);
	}		
	return 0;
}