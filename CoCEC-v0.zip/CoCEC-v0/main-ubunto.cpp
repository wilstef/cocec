
#include <string>
#include <iostream>

#include <stdlib.h>
#include <sstream> //for char to string conversion
#include <fstream>      // std::ifstream

#include "basicfuns.h"
#include "irgenerator.h"
#include "syntaxchecker.h"
#include "codegenerator.h"
#include "proofchecker.h"

#include "time.h"

using namespace std;

/*  Make the class name into a global variable  */
char szClassName[ ] = "BoolCheckWindowsApp";
//Two Boolean functions
string fun1 = " ";
string fun2 = " ";
string coqerror = " ";
bool validfuns = false;

string getinput(string fun) {
	string input;
	cout<<"Enter "<<fun<<" (without spaces): ";
	cin>>input;
return input;
}

int main() {

	//string input1;
	//string input2;
	do {
		fun1 = getinput("function 1");
		if (check_syntax(fun1)) {       //check syntax of entered function
			validfuns = true;
			fun1 = generateIR (fun1);	//translates to formalized Boolean functions					
		} else  {
			validfuns = false;
			syntaxerror = "Function 1 is invalid!\n"+syntaxerror+"\n";
			cout<<syntaxerror;
		}		
	} while (fun1 == " " | !validfuns);
	
	do {
		fun2 = getinput("function 2");
		if (check_syntax(fun2)) {       //check syntax of entered function
			validfuns = true;
			fun2 = generateIR (fun2);	//translates to formalized Boolean functions						
		} else  {
			validfuns = false;
			syntaxerror = "Function 2 is invalid!\n"+syntaxerror+"\n";
			cout<<syntaxerror;
		}		
	} while (fun2 == " " | !validfuns);
	
	
	string coqfile = mkcoqfile (fun1, fun2, 2); //checks the final (2) tactic.
	
	string dospath = "coqc \"" + getdestfilepath("balgebra.v");
	system(dospath.c_str()); 
	
	coqerror = proveequivalence (coqfile,fun1,fun2);
	
	if (coqerror == "unequal") {
		cout<<"\nFunctions are NOT equivalent!\n";
	}
	else if (coqerror == "equal") {
		cout<<"\nFunctions are equivalent!\n";
	}
	else {
		cout<<"\nError! Either Coq 8.8 is not installed or the function translation was not correct.\n";
	}

    return 0;
}
